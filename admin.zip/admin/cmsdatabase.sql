-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 15, 2010 at 02:26 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `cmsdatabase`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `countries`
-- 

CREATE TABLE `countries` (
  `name` varchar(100) collate latin1_general_ci NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `countries`
-- 

INSERT INTO `countries` (`name`) VALUES 
('United States'),
('Afghanistan'),
('Albania'),
('Algeria'),
('American Samoa'),
('Andorra'),
('Angola'),
('Anguilla'),
('Antarctica'),
('Antigua Barbuda'),
('Argentina'),
('Armenia'),
('Aruba'),
('Australia'),
('Austria'),
('Azerbaijan'),
('Bahamas'),
('Bahrain'),
('Bangladesh'),
('Barbados'),
('Belarus'),
('Belgium'),
('Belize'),
('Benin'),
('Bermuda'),
('Bhutan'),
('Bolivia'),
('Bosnia and Herzegovina'),
('Botswana'),
('Bouvet Island'),
('Brazil'),
('British Indian Ocean Territory'),
('British Virgin Islands'),
('Brunei'),
('Bulgaria'),
('Burkina Faso'),
('Burundi'),
('Cambodia'),
('Cameroon'),
('Canada'),
('Cape Verde'),
('Cayman Islands'),
('Central African Republic'),
('Chad'),
('Channel Islands'),
('Chile'),
('China'),
('Christmas Island'),
('Cocos (Keeling) Islands'),
('Colombia'),
('Comoros'),
('Congo'),
('Cook Islands'),
('Costa Rica'),
('Cote D''ivoire (Ivory Coast)'),
('Croatia'),
('Cuba'),
('Cyprus'),
('Czech Republic'),
('Denmark'),
('Djibouti'),
('Dominica'),
('Dominican Republic'),
('East Timor'),
('Ecuador'),
('Egypt'),
('El Salvador'),
('Equatorial Guinea'),
('Eritrea'),
('Estonia'),
('Ethiopia'),
('Falkland Islands (Malvinas)'),
('Faroe Islands'),
('Fiji'),
('Finland'),
('France'),
('France Metropolitan'),
('French Guiana'),
('French Polynesia'),
('French Southern Territories'),
('Gabon'),
('Gambia'),
('Georgia'),
('Germany'),
('Ghana'),
('Gibraltar'),
('Greece'),
('Greenland'),
('Grenada'),
('Guadeloupe'),
('Guam'),
('Guatemala'),
('Guinea'),
('Guinea-Bissau'),
('Guyana'),
('Haiti'),
('Heard McDonald Islands'),
('Honduras'),
('Hong Kong'),
('Hungary'),
('Iceland'),
('India'),
('Indonesia'),
('Iraq'),
('Ireland'),
('Islamic Republic of Iran'),
('Isle of Man'),
('Israel'),
('Italy'),
('Jamaica'),
('Japan'),
('Jordan'),
('Kazakhstan'),
('Kenya'),
('Kiribati'),
('Korea Democratic People''s Republic of'),
('Korea, Republic of'),
('Kuwait'),
('Kyrgyzstan'),
('Lao People''s Democratic Republic'),
('Latvia'),
('Lebanon'),
('Lesotho'),
('Liberia'),
('Libya'),
('Liechtenstein'),
('Lithuania'),
('Luxembourg'),
('Macau'),
('Macedonia, Republic of'),
('Madagascar'),
('Malawi'),
('Malaysia'),
('Maldives'),
('Mali'),
('Malta'),
('Marshall Islands'),
('Martinique'),
('Mauritania'),
('Mauritius'),
('Mayotte'),
('Mexico'),
('Micronesia'),
('Moldova'),
('Monaco'),
('Mongolia'),
('Monserrat'),
('Morocco'),
('Mozambique'),
('Myanmar'),
('Namibia'),
('Nauru'),
('Nepal'),
('Netherlands'),
('Netherlands Antilles'),
('New Caledonia'),
('New Zealand'),
('Nicaragua'),
('Niger'),
('Nigeria'),
('Niue'),
('Norfolk Island'),
('Northern Mariana Islands'),
('Norway'),
('Oman'),
('Pakistan'),
('Palau'),
('Panama'),
('Papua New Guinea'),
('Paraguay'),
('Peru'),
('Philippines'),
('Pitcairn'),
('Poland'),
('Portugal'),
('Puerto Rico'),
('Qatar'),
('Reunion'),
('Romania'),
('Russian Federation'),
('Rwanda'),
('Saint Lucia'),
('Saipan'),
('Samoa'),
('San Marino'),
('Sao Tome Principe'),
('Saudi Arabia'),
('Senegal'),
('Seychelles'),
('Sierra Leone'),
('Singapore'),
('Slovakia'),
('Slovenia'),
('Solomon Islands'),
('Somalia'),
('South Africa'),
('Spain'),
('Sri Lanka'),
('St. Helena'),
('St. Kitts and Nevis'),
('St. Pierre Miquelon'),
('St. Vincent the Grenadines'),
('Sudan'),
('Suriname'),
('Svalbard Jan Mayen Islands'),
('Swaziland'),
('Sweden'),
('Switzerland'),
('Syrian Arab Republic'),
('Taiwan'),
('Tajikistan'),
('Tanzania, United Republic of'),
('Thailand'),
('Togo'),
('Tokelau'),
('Tonga'),
('TrinidadTobago'),
('Tunisia'),
('Turkey'),
('Turkmenistan'),
('Turks Caicos Islands'),
('Tuvalu'),
('Uganda'),
('Ukraine'),
('United Arab Emirates'),
('United Kingdom (Great Britain)'),
('United States'),
('United States Minor Outlying Islands'),
('United States Virgin Islands'),
('Uruguay'),
('Uzbekistan'),
('Vanuatu'),
('Vatican City State (Holy See)'),
('Venezuela'),
('Viet Nam'),
('Wallis Futuna Islands'),
('Western Sahara'),
('Yemen'),
('Yugoslavia'),
('Zaire'),
('Zambia'),
('Zimbabwe'),
('Other');

-- --------------------------------------------------------

-- 
-- Table structure for table `groupmenurights`
-- 

CREATE TABLE `groupmenurights` (
  `groupid` int(5) NOT NULL default '0',
  `menuid` int(5) NOT NULL default '0',
  `position` varchar(5) character set latin1 NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `groupmenurights`
-- 

INSERT INTO `groupmenurights` (`groupid`, `menuid`, `position`) VALUES 
(91, 5, '3'),
(91, 4, '2'),
(92, 3, '2'),
(92, 1, '1'),
(91, 3, '5'),
(91, 2, '4'),
(91, 1, '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `groups`
-- 

CREATE TABLE `groups` (
  `id` int(5) NOT NULL default '0',
  `name` varchar(30) character set latin1 NOT NULL default '',
  `status` enum('Yes','No') character set latin1 NOT NULL default 'Yes',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `groups`
-- 

INSERT INTO `groups` (`id`, `name`, `status`) VALUES 
(91, 'CEO', 'Yes'),
(92, 'General', 'Yes');

-- --------------------------------------------------------

-- 
-- Table structure for table `groupsubmenurights`
-- 

CREATE TABLE `groupsubmenurights` (
  `groupid` int(5) NOT NULL default '0',
  `menuid` int(5) NOT NULL default '0',
  `submenuid` int(5) NOT NULL default '0',
  `position` int(3) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `groupsubmenurights`
-- 

INSERT INTO `groupsubmenurights` (`groupid`, `menuid`, `submenuid`, `position`) VALUES 
(92, 1, 44, 1),
(91, 2, 43, 6),
(91, 2, 42, 9),
(91, 2, 41, 8),
(91, 2, 40, 7),
(91, 2, 39, 5),
(91, 2, 38, 4),
(91, 2, 4, 3),
(91, 2, 3, 2),
(91, 2, 2, 1),
(91, 1, 44, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `items`
-- 

CREATE TABLE `items` (
  `id` int(10) NOT NULL auto_increment,
  `cid` int(10) NOT NULL,
  `sid` int(10) NOT NULL,
  `date` date NOT NULL,
  `title` varchar(255) collate latin1_general_ci NOT NULL,
  `description` text collate latin1_general_ci NOT NULL,
  `price` varchar(10) collate latin1_general_ci NOT NULL,
  `image` varchar(100) collate latin1_general_ci NOT NULL,
  `status` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=100076 ;

-- 
-- Dumping data for table `items`
-- 

INSERT INTO `items` (`id`, `cid`, `sid`, `date`, `title`, `description`, `price`, `image`, `status`) VALUES 
(100002, 100000, 100000, '2009-06-28', 'Summer Breeze Ball Pens', 'A high quality promotional pen at a great price and offering extra styling and personalization options.', '0.00', 'pe-6600-sm.jpg', 'Yes'),
(100001, 100000, 100000, '2009-06-24', 'Value Ball Pen', 'Offering a fantastic pen for the lower budgets. Available in a range of colours and offers\r\na shorter leadtime. ', '0.00', 'pe-7035-sm.jpg', 'Yes'),
(100003, 100000, 100000, '2009-06-28', 'Monza Plastic Pens', 'A great range of value budget pens in a range of\r\ncolourways which continue\r\nto be best sellers ', '0.00', 'pe-6113-sm.jpg', 'Yes'),
(100004, 100000, 100000, '2009-06-28', 'Styb Mega Frost Liquid Rollerball Pens', 'Smooth writing is assured\r\nwith these high quality liquid\r\ngel filled promotional\r\nroller ball pens ', '0.00', 'cg-1903-sm.jpg', 'Yes'),
(100005, 100000, 100000, '2009-06-28', 'Top Spin Plastic Ball Pens', 'Featuring a twist action mechanism and available in a wide range of colours, these\r\nlow cost promotional pens\r\nwill suit your budget ', '0.00', 'pe-6505-sm.gif', 'Yes'),
(100006, 100000, 100000, '2009-06-28', 'Popsicle Plastic Ball Pens', 'A brightly colored lightweight pen perfect for giveaways, available in a range of colors to suit your campaign.', '0.00', 'to-1021079-sm.jpg', 'Yes'),
(100007, 100000, 100009, '2009-06-28', 'Baron Plastic Ball Pens', 'These low cost pens are manufactured in a range of different colored trim options for a great giveaway ', '0.00', 'to-102221-sm.jpg', 'Yes'),
(100008, 100000, 100000, '2009-06-28', 'Slinky Ball Pens', 'The sleek slinky perfect for any occasion, corporate or casual; available in a range of colours.', '0.00', '102006-to-sm.jpg', 'Yes'),
(100009, 100000, 100000, '2009-06-28', 'Alpine Plastic Ball Pens', 'These best selling push action plastic promotional pens are a great way to promote your\r\nlogo around the office ', '0.00', 'pe-6000-sm.gif', 'Yes'),
(100010, 100000, 100000, '2009-06-28', 'Mega Plastic Ball Pens', 'Boasting an exceptional print area these chunky sized promotional pens are\r\nexcellent value ', '0.00', 'pe-6179f-sm.gif', 'Yes'),
(100011, 100000, 100000, '2009-06-28', 'Trans Compact Ball Pens', 'A lower budget pen offering a range of colours to suit your logo and great quality. ', '0.00', 'pe-7036-sm.jpg', 'Yes'),
(100012, 100000, 100000, '2009-06-28', 'Frosted Tornado Plastic Ball Pens', 'A highly popular range of\r\nplastic promotional pens which are manufactured in an\r\narray of frosted colourways\r\nfor a great giveaway ', '0.00', 'pe-6251-sm.gif', 'Yes'),
(100013, 100000, 100001, '2009-06-28', 'Windsor Metal Ball Pens', 'The new favourite within\r\nthe business industry,\r\nboasting a corporate, slender style with character.', '0.00', 'pe-6090b-sm.jpg', 'Yes'),
(100014, 100000, 100001, '2009-06-28', 'Silicon Grip Ball Pens', 'These Hi-tech metal ball pens feature a satin plated barrel ergo friendly rubber grip and a choice of trim colors ', '0.00', 'to-101005-sm.jpg', 'Yes'),
(100015, 100000, 100001, '2009-06-28', 'Atlantic Metal Ball Pens', 'These metal business printed pens are manufactured in\r\nmat silver with a choice of colored trim options ', '0.00', 'pe-6377-sm.jpg', 'Yes'),
(100016, 100000, 100001, '2009-06-28', 'Racing Metal Ball Pens', 'This stylish pen features a satin corporate barrel with metallic shaped trim in gold or blue, perfect for conferences ', '0.00', 'pe-6379-sm.jpg', 'Yes'),
(100017, 100000, 100001, '2009-06-28', 'Argente Metal Ball Pens', 'These stylish promotional pens feature a high quality\r\ncolored enamel finish\r\nin a range of colors ', '0.00', 'to-101001-sm.jpg', 'Yes'),
(100018, 100000, 100001, '2009-06-28', 'Sobe Metal Pens', 'The Sob metal pen is\r\noffered in a range of\r\ncorporate colrs combined\r\nwith black and silver trim. ', '0.00', 'plyfl-10608300-sm.jpg', 'Yes'),
(100019, 100000, 100001, '2009-06-28', 'Marakesh Pen', ' A funky styled pen offered in a variety of colour options and manufactured in a silver finish.\r\n', '0.00', 'plyfl-10608603-sm.jpg', 'Yes'),
(100020, 100000, 100001, '2009-06-28', 'Cepang Metal Ball Pens', 'A high quality pen in satin chrome and an array of colour options, ideal for trade shows ', '0.00', 'to-1011084-sm.jpg', 'Yes'),
(100021, 100000, 100001, '2009-06-28', 'India Metal Ball Pens', 'These stylish promotional metal pens come in navy or silver with quality metal trim fitments', '0.00', 'pens-74.gif', 'Yes'),
(100022, 100000, 100001, '2009-06-28', 'Texas Metal Ball Pens', 'A range of corporate pens available in a range of colours and supplied with blue ink', '0.00', 'texas-sm.jpg', 'Yes'),
(100023, 100000, 100001, '2009-06-28', 'Talin Ball Pens', 'A lightweight aluminum pus action high quality pen available in a range of colors.', '0.00', 'talin-sm.jpg', 'Yes'),
(100024, 100000, 100001, '2009-06-28', 'London Slimline Metal Pens', 'The elegant slimline pen supplied with blue ink and\r\ngold fitments. Perfect\r\nfor any occasion. ', '0.00', 'london-slim-sm.jpg', 'Yes'),
(100025, 100000, 100001, '2009-06-28', 'Zurich Metal Pens', 'An aluminium metal ballpen available in either black, silver or blue with a matt finish and silver trim fitments. ', '0.00', 'plyfl-10616300-sm.jpg', 'Yes'),
(100026, 100000, 100001, '2009-06-28', 'Baltic Metal Ball Pens', 'These top quality value ball pens are available in a\r\nrange of color options\r\nwith silver trimmings ', '0.00', 'pe-6300-sm.jpg', 'Yes'),
(100027, 100000, 100001, '2009-06-28', 'President Metal Ball Pens', 'These super slim range of office twist action action\r\nmetal pens come in a\r\nrange of color options', '0.00', 'pens-90.gif', 'Yes'),
(100028, 100000, 100002, '2009-06-28', '4 Colour Ball Pens', 'A great range quality pens which feature four different ink colors - highly popular\r\nwithin medical sectors ', '0.00', 'cg-1408-sm.gif', 'Yes'),
(100029, 100000, 100002, '2009-06-28', 'Leto Mutli Function Pens', 'The corporate favorite, offering a great style and practicality for those all important conferences.', '0.00', 'dk-3302-sm.jpg', 'Yes'),
(100030, 100000, 100002, '2009-06-28', 'Hearn Multi Function Pens', 'Superb value for money, offered in a range of\r\ncolors and offers more\r\nthan its writing functions. ', '0.00', 'dk-3306-sm.jpg', 'Yes'),
(100031, 100000, 100003, '2009-06-28', 'Daytona Flexible Pen', 'An ever popular range of pens that will draw the attention\r\nyou need. Available in\r\na range of colours. ', '0.00', 'kc-2567-sm.jpg', 'Yes'),
(100032, 100000, 100003, '2009-06-28', 'Bubble Neck Pens', 'Featuring a bubble blowing mechanism these pens will lift the spirit of any campaign. ', '0.00', 'it-2692-sm.jpg', 'Yes'),
(100033, 100000, 100003, '2009-06-28', 'Flat Pen', 'A unique range of printed flat pens available in a range\r\nof bright colors and\r\nfeaturing a thin, black strap. ', '0.00', 'kc-6818-sm.jpg', 'Yes'),
(100034, 100000, 100003, '2009-06-28', 'Styb Galaxy Novelty Neck Pens', 'Unusual designed neck pen featuring cord attachment\r\nwhich is available in a\r\nrange of trim colours', '0.00', 'cg-1536-sm.jpg', 'Yes'),
(100035, 100000, 100003, '2009-06-28', 'Styb Big Screen Novelty Message Ball Pens', 'A unique range of pens which offer a full 360 degree print on the rotating message panel. ', '0.00', 'pens-41.gif', 'Yes'),
(100036, 100000, 100003, '2009-06-28', 'Clip Logo Novelty Pens', 'A unique ball pen which features a totally customisable clip section for an\r\namazing low price. ', '0.00', 'pens-39.gif', 'Yes'),
(100037, 100000, 100003, '2009-06-28', 'Metro Bottle Opener Pen', 'A practical pen to give out\r\nwhich will most definitely keep your message going. ', '0.00', 'metro-sm.jpg', 'Yes'),
(100038, 100000, 100004, '2009-06-28', 'Parker Vector Rollerballs', 'Probably the most popular Parker pen of all time at a now available at an even lower price', '0.00', 'pens-14.gif', 'Yes'),
(100039, 100000, 100004, '2009-06-28', 'Frontier Stainless Steel Ball Pens', 'Shout out quality and performance at your next convention with these outstanding Parker Pens. ', '0.00', 'parker-frontier-ball-sm.jpg', 'Yes'),
(100040, 100000, 100004, '2009-06-28', 'Parker Latitude Ball Pen', 'Give your clients a gift that represents extreme quality and an elegant personality. ', '0.00', 'parker-lat-ball-sm.jpg', 'Yes'),
(100041, 100000, 100004, '2009-06-28', 'Stainless Steel Jotter Pen And Pencil Sets', 'Buy this pen and get a stainless steel jotter pencil absolutely free - simply amazing value ', '0.00', 'pens-18.gif', 'Yes'),
(100042, 100000, 100004, '2009-06-28', 'Jotter Traditional Silver Ball Pen', 'A classic and timeless range of all time best selling pens in a range of color options ', '0.00', 'pens-16.gif', 'Yes'),
(100043, 100000, 100004, '2009-06-28', 'Frontier Stainless Steel Rollerball Pen', 'Shout out quality and performance at your next convention with these outstanding Parker Pens. ', '0.00', 'parker-frontier-roller-sm.jpg', 'Yes'),
(100044, 100000, 100004, '2009-06-28', 'parker-frontier-roller-sm.jpg', 'Give your clients a gift that represents extreme quality and an elegant personality. ', '0.00', 'parker-lat-fountain-sm.jpg', 'Yes'),
(100045, 100000, 100177, '2009-06-28', 'Bic MediaClic Ball Pens', 'The most versatile and affordable ball point pen -\r\nwide range of mix and match barrel and clip colours\r\nto suit your image. ', '0.00', 'bic-spectrum-sm.jpg', 'Yes'),
(100046, 100000, 100177, '2009-06-28', 'BIC Grip Roller', 'A great branded BIC pens\r\nfor your next convention, offering extra smooth\r\nand precise writing. ', '0.00', 'roller-grip-sm.jpg', 'Yes'),
(100047, 100000, 100177, '2009-06-28', 'BIC Media Max Digital Ball Pen', 'Be really creative with these media max digital pens\r\noffering a 4 color process\r\nprint wrap to each pen. ', '0.00', 'media-max-sm.jpg', 'Yes'),
(100048, 100000, 100006, '2009-06-28', 'Round Stic Classic Ball Pens', 'The classic round stic ball pen available at a fantastic price, extremely reliable and\r\navailable in various colors. ', '0.00', 'roundstic-sm.jpg', 'Yes'),
(100049, 100000, 100177, '2009-06-28', 'Bic Matic Pencil', 'A very popular branded retractable pencil available\r\nin a range of colors\r\nat a great price. ', '0.00', 'bicmatic-sm.jpg', 'Yes'),
(100050, 100000, 100177, '2009-06-28', 'Bic Media Clic 360°', 'A great way to promote your full color branding - all round imaging - guaranteed\r\nimpact and quality ', '0.00', 'bic-360-sm.jpg', 'Yes'),
(100051, 100000, 100177, '2009-06-28', 'Clic Stic Classic Ball Pen', 'The iconic BIC design with a break resistant clip. Make sure you gift a reliable pen from a reliable manufacturer. ', '0.00', 'clic-stic-sm.jpg', 'Yes'),
(100052, 100000, 100177, '2009-06-28', 'Wide Body Digital Ball Pen', 'Offering a wider barrel for maximum brand visibility. Great value and a top quality\r\ngift for the price.', '0.00', 'wide-body-dig-sm.jpg', 'Yes'),
(100053, 100000, 100177, '2009-06-28', 'BIC Wide Body Ball Pen', 'Offering a wider barrel for maximum brand visibility.\r\nGreat value and a top\r\nquality gift for the price. ', '0.00', 'wide-body-sm.jpg', 'Yes'),
(100054, 100000, 100177, '2009-06-28', 'Sheaffer Sentinel Ball Pen', 'A traditional favorite for everyday use, offering different writing modes and various styles to suit your business. ', '0.00', 'sheaffer-sm.jpg', 'Yes'),
(100055, 100000, 100006, '2009-06-28', 'Bic Venture Ball Pen', 'Offering great printing options to get the best out of your logo and available in a good range of popular colors. ', '0.00', 'bu2-sm.jpg', 'Yes'),
(100056, 100000, 100005, '2009-06-28', 'Paper Mate Custom Rumour Pens', 'A great new style for that next convention, available in a range of colors and feature a rubber grip for extra comfort. ', '0.00', 'cg-2508-sm.jpg', 'Yes'),
(100057, 100000, 100005, '2009-06-28', 'Paper Mate Metal Pens', 'A sleek new style metal\r\npen available in a variety of colours and perfect for that\r\nnext conference. ', '0.00', 'cg-1118-sm.jpg', 'Yes'),
(100058, 100000, 100005, '2009-06-28', 'Paper Mate Custom 244 Pens', 'A mutual function pen\r\nfeaturing 4 different colours\r\nto suit all needs.', '0.00', 'cg-2501-sm.jpg', 'Yes'),
(100059, 100000, 100005, '2009-06-28', 'Paper Mate Curve Pens', 'A fantastic quality pen at\r\na great price from one of\r\nthe most well know\r\npen manufacturers. ', '0.00', 'pe-7034-sm.jpg', 'Yes'),
(100060, 100000, 100005, '2009-06-28', 'Paper Mate Custom Grip Gel Pens', 'A stylish example of a quality Paper Mate pen available\r\nin a range of colors to\r\nsuit your logo. ', '0.00', 'pe-6502-sm.jpg', 'Yes'),
(100061, 100000, 100005, '2009-06-28', 'Paper Mate Sharpie Marker Pens', 'This marker pen offers water resistant ink which can be used on nearly any surface.', '0.00', 'papermate-sharpie-sm.jpg', 'Yes'),
(100062, 100000, 100005, '2009-06-28', 'Paper Mate Stick Pens', 'A very reliable pen manufactured by one of the most well known pen suppliers, ideal for colleges and universities. ', '0.00', 'pe-7129-sm.jpg', 'Yes'),
(100063, 100000, 100005, '2009-06-28', 'Paper Mate Custom Click Pens', 'A simple style for perfect writing, ideal for trade shows and around the office. Available in a range of colors. ', '0.00', 'pe-6504-sm.jpg', 'Yes'),
(100064, 100000, 100006, '2009-06-28', 'Balmain Perpignon Pen Sets', 'A superb set of pens perfect for that all important conference or as a high quality gift for your valued customers', '0.00', 'perpignon-pen-sets-sm.gif', 'Yes'),
(100065, 100000, 100006, '2009-06-28', 'Balmain Etoile Pen Sets', 'A uniquely styled set of Balminess pens featuring a fantastic new look for your next conference', '0.00', 'etoile-pen-sets-sm.gif', 'Yes'),
(100066, 100000, 100007, '2009-06-28', 'Millau Leather Pen Sets', 'These stunning pen sets\r\nare manufactured to the highest of standards and feature leather trim ', '0.00', 'pens-121.gif', 'Yes'),
(100067, 100000, 100007, '2009-06-28', 'Algarve Pen Sets', 'A curve shaped presentation box with a transparent lid including 3 quality pens to satisfy every need. ', '0.00', 'algarve-sm.jpg', 'Yes'),
(100068, 100000, 100007, '2009-06-28', 'Victory Pensets', 'The victory pen sets offer a curvy, sleek style and include 2 like styled plastic pens, 1 roller ball and 1 ballpoint. ', '0.00', 'victory-sm.jpg', 'Yes'),
(100069, 100000, 100007, '2009-06-28', 'Balmain Perpignon Set', 'A superb set of pens perfect for that all important conference or as a high quality gift for your valued customers. ', '0.00', 'perpignon-pen-sets-sm.gif', 'Yes'),
(100070, 100000, 100007, '2009-06-28', 'Manufactured with a unique carbon finish these striking pen sets are the ultimate gift ', 'Manufactured with a unique carbon finish these striking pen sets are the ultimate gift ', '0.00', 'pens-33.gif', 'Yes'),
(100071, 100000, 100007, '2009-06-28', 'Sheaffer Prelude Pen Sets', 'Manufactured by a market leader these are an exceptional promotional pen set ', '0.00', 'pens-34.gif', 'Yes'),
(100072, 100000, 100007, '2009-06-28', 'Quantum Pensets', 'This striking executive promotional pen and pencil set combines hi-tech style with a solid muscular appearance ', '0.00', 'pens-32.gif', 'Yes'),
(100073, 100000, 100007, '2009-06-28', 'Titan Pen Sets', 'These ball pen and fountain pen sets are big on quality\r\nyet low on price ', '0.00', 'pens-31.gif', 'Yes'),
(100074, 100000, 100007, '2009-06-28', 'Balmain Etoile Pen Sets', 'A uniquely styled set of Balmain pens featuring a fantastic new look for your next conference.', '0.00', 'etoile-pen-sets-sm.gif', 'Yes'),
(100075, 100000, 100007, '2009-06-28', 'Stainless Steel Jotter Pen And Pencil Sets', 'Buy this pen and get a stainless steel jotter pencil absolutely free - simply amazing value ', '0.00', 'pens-18.gif', 'Yes');

-- --------------------------------------------------------

-- 
-- Table structure for table `menus`
-- 

CREATE TABLE `menus` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(50) character set latin1 NOT NULL default '',
  `link` varchar(60) character set latin1 NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `menus`
-- 

INSERT INTO `menus` (`id`, `name`, `link`) VALUES 
(1, 'Home', 'welcome.php'),
(2, 'Advance Tools', ''),
(3, 'Logout', 'include_member/member_logout.php'),
(4, 'Add Project', 'project_edit.php'),
(5, 'Project Listing', 'project_listing.php');

-- --------------------------------------------------------

-- 
-- Table structure for table `submenus`
-- 

CREATE TABLE `submenus` (
  `id` int(5) NOT NULL auto_increment,
  `menuid` int(5) NOT NULL default '0',
  `name` varchar(50) character set latin1 NOT NULL default '',
  `link` varchar(60) character set latin1 NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=56 ;

-- 
-- Dumping data for table `submenus`
-- 

INSERT INTO `submenus` (`id`, `menuid`, `name`, `link`) VALUES 
(2, 2, 'Menus', 'menus.php'),
(3, 2, 'Add Menu', 'addmenu.php'),
(4, 2, 'Add Submenu', 'addsubmenu.php'),
(38, 2, 'Change Password', 'member_pwd.php'),
(39, 2, 'Create Groups', 'group_edit.php'),
(40, 2, 'Create User', 'users.php'),
(41, 2, 'Group &amp; User Rights', 'groups_permission.php'),
(43, 2, 'Group Listing', 'groups.php'),
(42, 2, 'Users', 'user_listing.php');

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `userid` int(10) NOT NULL auto_increment,
  `groupid` varchar(20) character set latin1 NOT NULL default '',
  `loginid` varchar(75) character set latin1 NOT NULL default '',
  `firstname` varchar(75) character set latin1 NOT NULL default '',
  `lastname` varchar(75) character set latin1 NOT NULL default '',
  `pwd` varchar(50) character set latin1 default NULL,
  `email` varchar(255) character set latin1 NOT NULL default '',
  `emailpass` varchar(20) character set latin1 NOT NULL,
  `lastlogin` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` enum('Yes','No') character set latin1 NOT NULL default 'Yes',
  `master` enum('Yes','No') collate latin1_general_ci NOT NULL default 'No',
  PRIMARY KEY  (`userid`),
  KEY `groupid` (`groupid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1007 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` (`userid`, `groupid`, `loginid`, `firstname`, `lastname`, `pwd`, `email`, `emailpass`, `lastlogin`, `status`, `master`) VALUES 
(1002, '91', 'admin', 'Administrator', '', 'admin', '', '', '2008-09-01 00:00:00', 'Yes', 'No'),
(1005, '92', 'testing', 'Firstname', 'lastname', '123456', 'faisal.hexa@gmail.com', '', '2010-01-02 04:32:14', 'Yes', 'No');
