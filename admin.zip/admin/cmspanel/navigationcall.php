<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td class="win" align="center" width="200">Main Menu</td>
  </tr>
  <tr>
    <td><table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td width="10"></td>
          <td><? include("include_member/navigation.php");?></td>
        </tr>
      </table></td>
  </tr>
</table>
