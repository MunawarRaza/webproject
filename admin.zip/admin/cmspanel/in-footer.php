<?=FOOTER?>
<? /* this page use for footer ----------------------- 
<tr>
    <td width="984" height="50" align="center" bgcolor="#121c24" class="text1" colspan="2">&nbsp; &nbsp; &nbsp; Copyright &copy; 2009 <a href="http://www.almubdi.com">AlMubdi</a>. All Rights Reserved. </td>
  </tr>
 end of the code footer mpage------------------------------- */?>