<?include("./include/config.php");?>
<?include("./include/db.php");?>
<?include("./include_member/member_auth.php");?>
<?include("./include_member/member_secure.php");?>
<?include("./include/functions.php");?>
<?include("./include/validation.php");?>
<?include("./include/listing.php");?>
<? $db= new db();$db->connect(); $valid = new validation();?>
<? if(isset($_GET["_task"]) && $_GET["_task"]=="D"){
	$tb = $_GET["t"];
	$id = $_GET["id"];
	$sid = $_GET["sid"];
	if($tb=="main"){	
		$db->execute("DELETE FROM ".TBL_SUBMENUS." WHERE menuid='".$id."'");
		$db->execute("DELETE FROM ".TBL_MENUS." WHERE id='".$id."'");
	}else{
		$db->execute("DELETE FROM ".TBL_SUBMENUS." WHERE menuid='".$id."' and id='".$sid."'");
	}
}
?>
<? include("./include_member/header.php");?>
<tr>
<td align="center" coslpan="2">
	<table border="0" cellpadding="0" cellspacing="0" width="50%">
		<tr>
			<td align="center"><? $valid->show();?></td>
		</tr>
	</table>
</td>
</tr>
<tr>
<td align="center" colspan="2">
	<table border="0" cellpadding="0" cellspacing="0" width="100%">
		<tr>
			<td align="center"><? include("./include_member/displayerror.php"); ?></td>
		</tr>
	</table>
</td>
</tr>
<tr>
	<td colspan="2">
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
			    <td width="20" align="left" valign="top"></td>
				<td width="200" valign="top">
					<? include("navigationcall.php");?>
				</td>
				<td width="10"><? // Seperator --------?> </td>
				<td valign="top">
					<table border="0" cellpadding="0" cellspacing="0" width="100%">
						<tr>
							<td class="btitle">Menu &amp; Submenu Listing</td>
						</tr>
					</table><br />
					<table border="0" class="box1" width="100%" cellpadding="0" cellspacing="1" align="center">
						<tr class="th" height="22">
							<td></td>
							<td>ID</td>
							<td>Menu Names</td>
							<td>Page Link</td>
							<td>Edit</td>
							<th>Delete</th>
						</tr>
						<?  $subcount=0;
							$treecount=0;
							$style="tr1";						
							$rs_menu=$db->execute("SELECT id, name, link FROM ".TBL_MENUS." ORDER BY id");
							while($row_menu=$db->row($rs_menu)){?>
						<tr class="<?=$style?>">
							<td align="center" class="th"><img src=<?=IMGPLUS?> name="img<?=$treecount?>" onclick="DISPLAULISTING('<?=$treecount?>')"/></td>
							<td align="center"><?=$row_menu["id"]?></td>
							<td><label for="main_<?=$row_menu["id"]?>"><?=$row_menu["name"]?></label></td>
							<td><?=$row_menu["link"]?></td>
							<td align="center">
								<table border=0 cellspacing="0" cellpadding="1" width="100%">
								<tr>
									<td align="center" valign="middle"><a href="addmenu.php?mid=<?=$row_menu["id"]?>"><?=IMGEDIT?></a></td>
								</tr>
								</table>
							</td>
							<td align="center"><a href="menus.php?_task=D&t=main&id=<?=$row_menu["id"]?>"><?=IPDELETE?></a></td>
						</tr>
						<tr>
							<td colspan="6">
							<div id="tree_<?=$treecount?>" style="visibility: hidden; display:none">
								<table border="0" cellspacing="1" cellpadding="1" width="100%" align="center" class="box2">
								<tr class="th" height="22">
									<th class="th1" width="5%">Id</th>
									<th class="th1" width="40%">Submenu Name</th>
									<th class="th1" width="40%">Link</th>
									<th class="th1" width="15%">Action</th>
									<th class="th1" width="15%">Delete</th>
								</tr>
						<?	$style1="tr1";
							$rs_submenu=$db->execute("SELECT id, name ,link FROM ".TBL_SUBMENUS." WHERE menuid='".$row_menu["id"]."'ORDER BY id");
							while($row_submenu=$db->row($rs_submenu)){	?>
								 <tr class="<?=$style1?>">
									 <td align="center"><?=$row_submenu["id"]?></td>
									 <td><?=$row_submenu["name"]?></td>
									 <td><?=$row_submenu["link"]?></td>		
									 <td align="center">
									   <table border=0 cellspacing="0" cellpadding="0" width="100%">
										<tr>
											<td align="center" valign="middle"><a href="addsubmenu.php?sid=<?=$row_submenu["id"]?>&menuid=<?=$row_menu["id"]	?>"><?=IMGEDIT?></a></td>
										</tr>									
										</table>
									</td>	
									<td align="center"><a href="menus.php?_task=D&t=sub&id=<?=$row_menu["id"]?>&sid=<?=$row_submenu["id"]?>"><?=IPDELETE?></a></td>
								</tr>
								<? $style1=="tr1" ? $style1="tr2" : $style1="tr1"; $subcount++;
								}?>
								</table>
							</div>
						<?
							$subcount=0;$treecount++;$style=="tr1" ? $style="tr2" : $style="tr1";
						}?>	
						</td>
						</tr>
						</table>
				</td>
				<td width="20" align="left" valign="top"></td>
			</tr>
		</table>
	</td>
</tr>
<script language="javascript">
	function DISPLAULISTING(tn){
			dv = document.getElementById("tree_"+tn);
				if(dv.style.visibility=="hidden"){
						dv.style.visibility="visible";
						dv.style.display="block";
						document.images['img'+tn].src="images/btn_mins.gif"; 
					}
				else{
						dv.style.visibility="hidden";
						dv.style.display="none";
						document.images['img'+tn].src="images/btn_plus.gif"; 
				}
					
		}
		
	function SELECTALL(st,en){
		aleret(st);
		for(x=st;x<=en;x++){
			document.frmedit.x.checked=true;
		}
	}
</script>
<? include("./include_member/footer.php");?>