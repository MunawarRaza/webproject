<?
define("IMGDETAIL","<img src='images/btn_detail.gif' height='16' width='16' border='0' alt='click here to see details.'>");
define("IMGPASS","<img src='images/btn_password.gif' height='16' width='16' border='0' alt='click here to change password.'>");
define("IMGEDIT","<img src='images/btn_edit.gif' height='16' width='16' border='0' alt='click to edit/update item.' border='0'>");
define("IMGDATE","<img src='images/btn_datetime.gif' height='16' width='16' border='0' alt='click to select a date.'>");
define("IPDELETE","<img src='images/btn_delete.gif' height='16' width='16' alt='click to delete item.' border='0'>");
define("IPVALID","<img src='images/btn_valid.gif' height='16' width='16' alt='click to deactivate item.' border='0'>");
define("IPINVALID","<img src='images/btn_invalid.gif' height='16' width='16' alt='click to activate item.' border='0'>");
define("IPMASTER","<img src='images/per.ico' height='20' width='20' alt='Permenant.' border='0'>");
define("IPINMASTER","<img src='images/tem.ico' height='20' width='20' alt='Temparary.' border='0'>");
define("IPNO","src='images/btn_no.gif' height='16' width='16'");
define("IPYES","src='images/btn_yes.gif' height='16' width='16'");
define("IPCHECKALL","SRC='images/btn_check_on.gif' WIDTH='16' HEIGHT='16' BORDER='0' ALT='Check All'");
define("IPUNCHECKALL","SRC='images/btn_check_off.gif' WIDTH='16' HEIGHT='16' BORDER='0' ALT='Un Check All'");
define("IMGPLUS","images/btn_plus.gif");
define("IMGMINUS","images/btn_mins.gif");
define("SS","<img src='images/ss.png' title='Short Shippment' alt='Short Shippment'>");
define("IM","<img src='images/invoicematched.gif' title='Invoice Matched' alt='Invoice Matched'>");
define("FL","<img src='images/flag.png' title='Flag' alt='Flag'>");
define("QY","<img src='images/query.png' title='Query' alt='Query'>");
define("NOTFOUND", "<font class='nf'>Record Not Found</font>"); // record not found message
define("UPGRD", "<img src='images/upgrd.gif' width=10 height=10> "); // ugrade icon
define("PAID", "<img src='images/paid.gif' width=16 height=16> "); // paid sign image
define("TIP", "<img src='images/tips.gif' border='0' align='left'>"); // tip image
define("CLOSE", "<img src='images/close.jpg' border='0'>"); // cross image
define("PROGRESSBAR", "<img src='images/progressbar.gif' border='0'>"); // cross image
define("XERROR","<img src='images/_btn_error.gif' border='0'>"); // error / alert image
define("AB_PATH_CLIENT","./");
?>